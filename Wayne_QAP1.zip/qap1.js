// Select elements
const items = document.querySelectorAll('.slider .list .item');
const next = document.getElementById('next');
const prev = document.getElementById('prev');
const thumbnails = document.querySelectorAll('.thumbnail .item');

// Configuration
let itemActive = 0;
const countItem = items.length;

// Event handlers
next.onclick = () => updateSlider((itemActive + 1) % countItem);
prev.onclick = () => updateSlider((itemActive - 1 + countItem) % countItem);

// Auto-run slider
let refreshInterval = setInterval(() => next.click(), 5000);

// Update slider display
function updateSlider(index) {
    items[itemActive].classList.remove('active');
    thumbnails[itemActive].classList.remove('active');
    itemActive = index;
    items[itemActive].classList.add('active');
    thumbnails[itemActive].classList.add('active');
    clearInterval(refreshInterval);
    refreshInterval = setInterval(() => next.click(), 5000);
}

// Thumbnail click event
thumbnails.forEach((thumbnail, index) => {
    thumbnail.addEventListener('click', () => updateSlider(index));
});
